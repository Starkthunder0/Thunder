# Stark CC Checker Bot

## Overview
This is a Telegram bot that checks credit cards using the Stripe API. It supports single card checks (`/chk`) and mass checks (`/check`), attempting to charge $1 per card. Only cards that successfully process a $1 charge are reported. The `/chk` command is free for all users with a 10-second delay between checks. Mass checks via `/check` are limited to 1000 cards per file for premium users and the owner. The bot includes a redeem code system for premium access, a broadcast system for the owner, and a `/stop` command to halt ongoing checks.

## Setup Instructions
1. **Install Python**: Ensure you have Python 3.8 or higher installed.
2. **Install Dependencies**:
   Run the following command in your terminal: